/** @file extensions.h
 *	@brief	One-sentence short description of file.
 *
 *	Description:
 *
 *	Copyright (c) 2017 Kevin L. Becker. All rights reserved.
 *
 *	Original:
 *	Created on: Jan 24, 2017
 *	Author: kbecker
 *
 *	Current:
 *	$Revision: $
 *	$Date: $
 */

#ifndef EXTENSIONS_H_
#define EXTENSIONS_H_

#ifdef	__cplusplus
extern "C" {
#endif

// ============================================================================
// ----	Include Files ---------------------------------------------------------
// ============================================================================

// ----	System Headers --------------------------
#include <stdio.h>		// setvbuf() in windows

// ----	Project Headers -------------------------
#include "ptypes.h"		/* project (or "portable") types */

// ----	Module Headers --------------------------


// ============================================================================
// ----	Constants -------------------------------------------------------------
// ============================================================================
#define EXTENSIONS_H__REVSTRING "$Revision: 0123 $"

/* So that the mechanism of detecting the configuration from within the IDE
 * works the same in Eclipse and MPLAB X, define here a symbol so that
 * XPRJ_Debug takes on a value of 1.
 *
 * Note, Because MPLab's new project wizard wants to create a configuration of
 * "Default", use that to detect when we're on a PIC32 instead of a desktop.
 */
#if defined(XPRJ_Debug)
#define Debug 1
#define XPRJ_Default 0
#elif defined(XPRJ_Default)
#define XPRJ_Debug 0
#define Default 1
#endif


/* ==== A WORD ABOUT BUILD TARGETS ============================================
 *	Within Eclipse, the configuration is available as an IDE variable named
 *		"${ConfigName}"
 *	This can be put into a command-line define, for use in the code itself;
 *	within this project's settings, this is done by defining
 *		"XPRJ_${ConfigName}"
 *
 *	Use by preprocessor code such as
 *		"#if defined(XPRJ_Debug)"
 *
 *	Note the name of this define is specifically chosen for cross-platform
 *	Compatibility, for example with MPLAB X.
 *
 *	Within the NetBeans IDE used by MPLAB X, the equivalent mechanism is to
 *	detect off the command-line define "XPRJ_<config>",
 *		"#if defined(XPRJ_Debug)"
 *
 *	Note the name of the default configuration created by MPLAB X' New Project
 *	wizard is "default" - if you want a configuration named "Debug", you need to
 *	create it.
 *
 *	Within my development environment, I let Eclipse' New Project Wizard create
 *	its standard Debug and Release configurations, then create new ones for on-
 *	target debugging, as required. I assume my Windows/Linux Debug configuration
 *	is also intended for unit tests, so I rather indiscriminently print things
 *	to the console.
 * ========================================================================= */


// ============================================================================
// ----	Type Definitions ------------------------------------------------------
// ============================================================================

// ============================================================================
// ----	Public Variables ------------------------------------------------------
// ============================================================================

// ============================================================================
// ----	Public API ------------------------------------------------------------
// ============================================================================

/**	Macro to allow (for example) the use of enumeration names in a string. */
#define TO_STRING(x)			#x

/**	Extract the low-order byte out of a 16-bit word. */
#define LSB_16(word16)			(tU8)((tU16)word16 & (tU8)0xFF)

/** Extract the low-order word out of a 32-bit dword */
#define LSW_32(word32)			(tU16)((tU32)word32 & (tU16)0xFFFF)

/**	Extract the high-order byte out of a 16-bit word. */
#define MSB_16(word16)			(tU8) (((tU16)word16  /   0x100U) &  (tU8)0xFF)

/** Extract the high-order word out of a 32-bit dword */
#define MSW_32(word32)			(tU16)((((tU32)word32) / 0x10000U) & (tU16)0xFFFF)


#define BIT_TEST(mem, bit)		((mem)&(1<<(bit)))
#define BIT_SET(mem, bit)		((mem)|=(1<<(bit)))
#define BIT_CLR(mem, bit)		((mem)&=~(1<<(bit)))
#define BIT_TOGGLE(mem, bit)	((mem)^=(1<<(bit)))


/** Determine the number of elements in a table */
#define TABLE_SIZE(table)		(sizeof(table) / sizeof(table[0]))


/**	Determine if "a" is in between values "low" and "hi", inclusive.
 *	@note This macro is not safe, in that it evaluates one or more arguments
 *	more than once.
 */
#define IN_RANGE(val, low, hi)	(((val) <= (low)) && ((val) >= (hi)))


/**	Determine the number of elements in an array.
 * @return The number of elements in the specified array.
 * \note In some environments, given certain compiler optimization settings, this version may return a signed char.
 * Be sure to test its use on arrays with more than 127 elements.
 */
#define NUM_ARRAY_ELEMENTS(arrayref)     (sizeof(arrayref) / sizeof(arrayref[0]))


//! Return the maximum value of two parameters.
//! When available, this macro should be an alias for the compiler-supplied version.
//! This version is provided for compilers that do not provide an intrinsic version.
//! \note This version is \b UNSAFE in that it has side effects (it evaluates one or more arguments more than once)
#if defined(_MSC_VER)
    // msvc has max/min in stdlib, gnuc evidently doesn't
    #define MAX(a, b)	max(a, b)

#else
    #define MAX(a, b)   (((a) > (b)) ? (a) : (b))

#endif

//! Return the minimum value of two parameters.
//! When available, this macro should be an alias for the compiler-supplied version.
//! This version is provided for compilers that do not provide an intrinsic version.
//! \note This version is \b UNSAFE in that it has side effects (it evaluates one or more arguments more than once)
#if defined(_MSC_VER)
    // msvc has max/min intrinsics in stdlib, gnuc evidently doesn't
    #define MIN(a, b)   min(a, b)

#else
    #define MIN(a, b)   (((a) < (b)) ? (a) : (b))

#endif


/**	Eliminate compiler and static-checker warnings about an unused function
 *	parameter.
 */
#if !defined(UNUSED)
#define UNUSED(x) (void)x
#endif


/**	Abstract module initialization.
 *	The intention is, all modules use the same signature for their init
 *	function, so make it more obvious to the code maintainer that we're
 *	using a standardized (template) init function.
 *
 *	There is a 2-layer expansion because it is possible the argument could of
 *	itself be a macro; for example, if the module source, header, and function
 *	prefixes were all the same, and so a macro was defined to represent that
 *	module.
 */
#define Init(instance)	_init(instance)
#define _init(instance)	instance ## _Init()
typedef int (*fpInit)(void);


/**	Module task function.
 */
#define Task(instance)	_task(instance)
#define _task(instance)	instance ## _Task()
typedef void (*fpTask)(void);


/**
\page Get_Macro                 GET(channel)
    \anchor interfaces_get_macro
    With this macro, we are taking the viewpoint that all external entities shall be read through a standard channel.
    \par Benefits:
    -   The API can be easily changed, to include debugging code, or to customize the source of the data according to
        the environment - the source can be controlled programmatically in a Unit Test environment, or from "the
        simulator" in a simulation environment, etc.  It can be used to feed data from an external source in diagnostics
        mode and from the true source in normal mode.  It can be made to emit a broadcast notification that "somebody"
        read from that channel.
    -   It encourages a consistent method of getting information from outside of the module.  In the present body of
        Dish code, there is a wide variety of methods used, and almost no consistency in naming, even in code that has
        been written recently.
    -   In some IDEs (notably, MSVC), if the macro is a simple redirection to a variable or function, the IDE can take
        you right to the macro target.
    \par Disadvantages:
    -   On a per-module basis, the number of "channels" to be read is usually small and manageable, but in a large
        application, the list of channels can be large.  Because the macro argument is not an enumerated symbol or
        #define, the IDE cannot take you to its definition.  While management is not hard, it does require rigor without
        the automated aid of the IDE.
    \n
    \sa \ref GET()
*/
/**
 * Proposed attribute getter.
 * This is intended for usage within the module's implementation, whenever it wants to read the present value of \b any
 * external attribute.  The expanded symbol should be defined in the module where it's used, and can be simply an alias
 * for an LSI getter function, or it could implement some algorithm or logic to decide what to return.
 *
 * Usage:
 * - In implementation file, where used:
 * \verbatim local_var = GET(DOOR_OPEN); \endverbatim
 *
 * - In module's PRV header, where defined:
 * \verbatim #define GET_DOOR_OPEN()   Lsi__GetDigitalInput(DI_DOOR_OPEN) \endverbatim
 *
 * A word about why there are two back-to-back macros:
 * When using macro concatenation, "C" concatenates, then attempts to expand the new symbol.
 * We want to make sure \arg input, which might be a define-of-a-define(-of-a-define), is fully expanded \b before
 * concatenation occurs.
 *
 * \sa \ref Get_Macro
 */
//! @{
#define GET(input)              _GET(input)         /* expand argument, if, for example, argument is itself a macro */
#define _GET(input)             GET_ ## input()     /* expand (which should now be complete), then concatenate */
//! @}

/**	Is specified condition true?
 *	@return #TRUE if condition is true, #FALSE otherwise.
 */
#define IS(cond)                (bool)(GET(cond) != false)


/**	NON-PRODUCTION interface to "get" an internal variable.
 *	This is designed to be a sort of extension of the Init(module) and
 *	Task(module) API; in the same way, you "Get(module, attribute)".
 */
#define GET2(component, resource)	_get2(component, resource)
#define _get2(component, resource)	Get_ ## component(resource)

/**	Pre-configured "module" named "Dbg" (Debug) for use with the above Get()
 *	API. To use this, you will need to create a symbol in your module that looks
 *	like "Get_Dbg_resource()". if you want this to be a macro, fine, or a "real"
 *	function, hey, roll with it.
 */
#define Get_Dbg(resource)			_get_debug(resource)
#define _get_debug(resource)		Get_Dbg_ ## resource()


/*	=== dev-on-PC API =========================================================
 */
#if defined(__GNUC__)	/* --- GNU Environment ------------------------------ */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wvariadic-macros"
#else

#endif

#if (XPRJ_Debug)
/*	per https://gcc.gnu.org/onlinedocs/cpp/Variadic-Macros.html, variadics used
 *	as i'm using them here, will break on a non-GNU compiler. buyer beware.
 */
#define	dprintf(format, args...)	(void)printf(format , ## args)

/*	within eclipse mars, on windows, using mingw, it seems that stdout
 *	buffering is broken. the advice i've found is to disable said
 *	buffering. this is supposed to do that.
 *
 *	the alternative would be to directly open a console window. this
 *	involves changing .gdbinit and is described at
 *	http://stackoverflow.com/questions/13035075/printf-not-printing-on-console
 *	and
 *	https://mirlab.wordpress.com/2014/02/23/no-console-output-in-eclipse-with-cdt-in-windows/
 */
#define disable_console_buffering()	setvbuf(stdout, NULL, _IONBF, 0)

/**	when built on a PC, it's likely i want to see module elements that we would
 *	otherwise want to keep secret.
 */
#define PRIVATE						/* nothing */

#else
#error no
#define dprintf(format, args...)	do {} while(0)
#define disable_console_buffering()	do {} while(0)


/**	when built on a PC, it's likely i want to see module elements that we would
 *	otherwise want to keep secret.
 */
#define PRIVATE						static

#endif

#if defined(__GNUC__)	/* --- /GNU Environment ----------------------------- */
#pragma GCC diagnostic pop
#endif


/**	Core library init function. Only needs to be called once, probably by main
 *	application (rather than all components which use this core library).
 *	Meant to be called via "int initerr = Init(Lib);"
 */
extern void Lib_Init(void);


#ifdef	__cplusplus
}
#endif

#endif /* EXTENSIONS_H_ */
